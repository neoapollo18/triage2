import os
import json
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import pandas as pd
from category_encoders import OrdinalEncoder
from sklearn.preprocessing import StandardScaler

# Load model architecture (copying relevant parts from your training code)
class TowerBlock(nn.Module):
    def __init__(self, num_features, vocab_dict, bin_features, emb_dim=32):
        super().__init__()
        # numeric feature processing
        self.num_proj = nn.Sequential(
            nn.Linear(num_features, emb_dim),
            nn.LayerNorm(emb_dim),
            nn.GELU(),
            nn.Dropout(0.1)
        )
        
        # categorical embeddings
        self.embeddings = nn.ModuleDict({
            name: nn.Embedding(size, emb_dim)
            for name, size in vocab_dict.items()
        })
        
        # binary features projection
        self.bin_proj = nn.Sequential(
            nn.Linear(bin_features, emb_dim),
            nn.LayerNorm(emb_dim),
            nn.GELU(),
            nn.Dropout(0.1)
        )
        
        # feature interaction
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=emb_dim,
            nhead=4,
            dim_feedforward=emb_dim * 4,
            dropout=0.1,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=2
        )
        
        # Output projection
        self.out_proj = nn.Sequential(
            nn.Linear(emb_dim, emb_dim * 2),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(emb_dim * 2, emb_dim)
        )

    def forward(self, num, cat, bin):
        # Process numeric features
        num_emb = self.num_proj(num).unsqueeze(1)
        
        # Process categorical features
        cat_embs = []
        for i, (name, emb) in enumerate(self.embeddings.items()):
            cat_embs.append(emb(cat[:, i]))
        cat_emb = torch.stack(cat_embs, dim=1)
        
        # Process binary features
        bin_emb = self.bin_proj(bin).unsqueeze(1)
        
        x = torch.cat([num_emb, cat_emb, bin_emb], dim=1)
        
        x = self.transformer(x)
        
        # Pool and project
        x = x.mean(dim=1)
        x = self.out_proj(x)
        
        return F.normalize(x, p=2, dim=1)

class MatchingModel(nn.Module):
    def __init__(self, encoder):
        super().__init__()
        # Business tower
        self.business_tower = TowerBlock(
            num_features=len(encoder.num_bus) + len(encoder.states),
            vocab_dict=encoder.vocab_bus,
            bin_features=len(encoder.bin_bus)
        )
        
        # 3PL tower
        self.threepl_tower = TowerBlock(
            num_features=len(encoder.num_tpl) + len(encoder.states),
            vocab_dict=encoder.vocab_tpl,
            bin_features=len(encoder.bin_tpl)
        )

    def forward(self, business_data, threepl_data):
        bus_num, bus_cat, bus_bin = business_data
        tpl_num, tpl_cat, tpl_bin = threepl_data
        return self.business_tower(bus_num, bus_cat, bus_bin), self.threepl_tower(tpl_num, tpl_cat, tpl_bin)

# Inference functions for SageMaker
def model_fn(model_dir):
    """Load the PyTorch model and encoder from the saved state."""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # Load the model checkpoint which contains the model and encoder state
    checkpoint = torch.load(os.path.join(model_dir, "best_model.pt"), map_location=device)
    
    # Extract the encoder state and model state dict
    encoder = checkpoint['encoder_state']
    model = MatchingModel(encoder)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.to(device)
    model.eval()
    
    return {'model': model, 'encoder': encoder}

def input_fn(request_body, request_content_type):
    """Parse input data for prediction."""
    if request_content_type == 'application/json':
        data = json.loads(request_body)
        
        # Check which type of data is provided
        if 'business' in data and '3pl' in data:
            # Both a business and a 3PL for matching
            return {'business': pd.DataFrame([data['business']]), 
                    '3pl': pd.DataFrame([data['3pl']])}
        elif 'business' in data:
            # Just a business to encode
            return {'business': pd.DataFrame([data['business']])}
        elif '3pl' in data:
            # Just a 3PL to encode
            return {'3pl': pd.DataFrame([data['3pl']])}
        else:
            raise ValueError("Input must contain 'business', '3pl', or both")
    else:
        raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_data, model_with_encoder):
    """Generate prediction based on input data."""
    model = model_with_encoder['model']
    encoder = model_with_encoder['encoder']
    
    model.eval()
    with torch.no_grad():
        # Handle different input types
        if 'business' in input_data and '3pl' in input_data:
            # Encode business data
            bus_data = encoder.encode_business(input_data['business'])
            bus_data = tuple(t.to(next(model.parameters()).device) for t in bus_data)
            
            # Encode 3PL data
            tpl_data = encoder.encode_3pl(input_data['3pl'])
            tpl_data = tuple(t.to(next(model.parameters()).device) for t in tpl_data)
            
            # Get embeddings
            bus_emb, tpl_emb = model(bus_data, tpl_data)
            
            # Calculate similarity score
            similarity = F.cosine_similarity(bus_emb, tpl_emb)
            # Scale to [0,1]
            similarity = (similarity + 1) / 2
            
            return {
                'similarity_score': similarity.item(),
                'business_embedding': bus_emb.cpu().numpy().tolist(), 
                'threepl_embedding': tpl_emb.cpu().numpy().tolist()
            }
        
        elif 'business' in input_data:
            # Only encode business
            bus_data = encoder.encode_business(input_data['business'])
            bus_data = tuple(t.to(next(model.parameters()).device) for t in bus_data)
            bus_emb = model.business_tower(*bus_data)
            return {'business_embedding': bus_emb.cpu().numpy().tolist()}
        
        elif '3pl' in input_data:
            # Only encode 3PL
            tpl_data = encoder.encode_3pl(input_data['3pl'])
            tpl_data = tuple(t.to(next(model.parameters()).device) for t in tpl_data)
            tpl_emb = model.threepl_tower(*tpl_data)
            return {'threepl_embedding': tpl_emb.cpu().numpy().tolist()}

def output_fn(prediction, response_content_type):
    """Format prediction for output."""
    if response_content_type == 'application/json':
        return json.dumps(prediction)
    else:
        raise ValueError(f"Unsupported content type: {response_content_type}")